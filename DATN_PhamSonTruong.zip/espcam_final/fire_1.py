from ultralytics import YOLO
import cvzone
import cv2
import math
import numpy as np
import mysql.connector
from datetime import datetime
#import urllib3
import urllib.request
import random
import string
# Running real time from webcam
url = 'http://192.168.0.102/cam-hi.jpg'
cap = cv2.VideoCapture(url)
model = YOLO('best_1.pt')

# Reading the classes
classnames = ['fire']

Fire_Reported = 0
prevFireReport = 0
isFireDetected = "Not detected"

# specify database connect to
db = mysql.connector.connect(user='root', password='', host='localhost', database='esp32_mc_db')


while (cap.isOpened()):
    # img_resp=urllib3.request("GET",url)
    img_resp = urllib.request.urlopen(url)
    imgnp = np.array(bytearray(img_resp.read()), dtype=np.uint8)
    im = cv2.imdecode(imgnp, -1)
    ret, frame = cap.read()
    #frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)
    #frame = cv2.resize(frame,(640,480))
    result = model(im, stream=True) # frame -> im
    prevFireReport = Fire_Reported
    # Getting bbox,confidence and class names informations to work with
    for info in result:
        boxes = info.boxes
        for box in boxes:
            confidence = box.conf[0]
            confidence = math.ceil(confidence * 100)
            Class = int(box.cls[0])
            if confidence > 50:
                x1, y1, x2, y2 = box.xyxy[0]
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                cv2.rectangle(im, (x1, y1), (x2, y2), (0, 0, 255), 5) #frame ->im
                cvzone.putTextRect(im, f'{classnames[Class]} {confidence}%', [x1 + 8, y1 + 100],
                                   scale=1.5, thickness=2)
                Fire_Reported += 1

    if (Fire_Reported >= 1 and Fire_Reported != prevFireReport):
        isFireDetected = "Detected fire"
    else:
        isFireDetected = "Not detected"
    print(isFireDetected)

    now = datetime.now()
    formatted_datetime = now.strftime('%Y-%m-%d %H:%M:%S')
    date_time_split = formatted_datetime.split(" ")
    date = date_time_split[0]
    time = date_time_split[1]

    random_string_id = ''.join(random.choice(string.ascii_letters) for i in range(10))

    code = """UPDATE esp32_cam set fire_status = %s, time = %s, date = %s WHERE id = 'esp32_01'"""
    val = [(isFireDetected, time, date)]
    mycursor = db.cursor()
    for item in val:
        mycursor.execute(code, item)
    db.commit()
    
    cv2.imshow('frame', im) #('frame',frame)
    cv2.waitKey(1)
